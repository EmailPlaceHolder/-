local target = ""

game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("🔓: Cracking "..target.."'s IP Address..." ,"All")

wait(3)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("📟: Decrypting "..target.."'s IP Address" ,"All")

wait(2)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("✅20% ✅40% ✅60% completed." ,"All")

wait(1)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("📤: "..target.."'s IP has been unhashed," ,"All")

wait(2)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("🔏: Successfully taken "..target.."'s IP..." ,"All")

wait(1)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("🔑: Successfully logged "..target.."'s IP!" ,"All")

wait(2)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("IP: (Saved Notes) Pinned: Street" ,"All")

wait(4)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("Thank you, "..target..". 🙂" ,"All")

warn("🔓: Cracked "..target.."'s IP Address")