-- Made by Cole

local target = game.Players[''] -- Target

-- Identifiers

    local name = target.Name

    local userid = target.UserId
    local accountage = target.AccountAge
    local membershiptype = target.MembershipType.Name

-- Prompts

    game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(name.."'s User Id - roblox.com/library/"..userid,"All")
    wait(0.1)
    game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(name.."'s Account Age - "..accountage.." days","All")
    wait(0.1)
    game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer(name.."'s Membership - "..membershiptype,"All")

    warn("Target -",target)
    wait(1)
    print("User Id #",userid)
    wait(0.1)
    print("Account Age -",accountage,"days")
    wait(0.1)
    print("Membership Type -",membershiptype)