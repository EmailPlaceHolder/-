-- Made by Cole

game.Players.LocalPlayer.Backpack:ClearAllChildren()