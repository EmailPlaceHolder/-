-- Made by Cole
-- Open Console

local target = game.Players[''] -- Target

-- Identifiers

    local accountage = target.AccountAge
    local archivable = target.Archivable
    local autojumpenabled = target.AutoJumpEnabled
    local cameramaxzoomdistance = target.CameraMaxZoomDistance
    local cameraminzoomdistance = target.CameraMinZoomDistance
    local cameramode = target.CameraMode.Name
    local canloadcharacterappearance = target.CanLoadCharacterAppearance
    local character = target.Character
    local characterappearance = target.CharacterAppearance
    local chatmode = target.ChatMode.Name
    local classname = target.ClassName
    local datacost = target.DataCost
    local devcameraocclusionmode = target.DevCameraOcclusionMode.Name
    local devcomputercameramode = target.DevComputerCameraMode.Name
    local devcomputermovementmode = target.DevComputerMovementMode.Name
    local devenablemouselock = target.DevEnableMouseLock
    local devtouchcameramode = target.DevTouchCameraMode.Name
    local devtouchmovementmode = target.DevTouchMovementMode.Name
    local displayname = target.DisplayName
    local followuserid = target.FollowUserId
    local guest = target.Guest
    local healthdisplaydistance = target.HealthDisplayDistance
    local maximumsimulationradius = target.MaximumSimulationRadius
    local membershiptype = target.MembershipType.Name
    local name = target.Name
    local namedisplaydistance = target.NameDisplayDistance
    local neutral = target.Neutral
    local osplatform = target.OsPlatform
    local parent = target.Parent
    local replicationfocus = target.ReplicationFocus
    local respawnlocation = target.RespawnLocation
    local robloxlocked = target.RobloxLocked
    local team = target.Team
    local teamcolor = target.TeamColor
    local teleportedin = target.TeleportedIn
    local userid = target.UserId
    local vrdevice = target.VRDevice
    local hasverifiedbadge = target.HasVerifiedBadge
    local gameplaypaused = target.GameplayPaused

-- Prompts

    warn("Target -",target)
    wait(1)
    print("Account Age -",accountage,"days")
    wait(0.1)
    print("Archivable =",archivable)
    wait(0.1)
    print("Auto Jump Enabled =",autojumpenabled)
    wait(0.1)
    print("Camera Max Zoom Distance -",cameramaxzoomdistance)
    wait(0.1)
    print("Camera Min Zoom Distance -",cameraminzoomdistance)
    wait(0.1)
    print("Camera Mode -",cameramode)
    wait(0.1)
    print("Can Load Character Appearance =",canloadcharacterappearance)
    wait(0.1)
    print("Character -",character)
    wait(0.1)
    print("Character Appearance -",characterappearance)
    wait(0.1)
    print("Chat Mode -",chatmode)
    wait(0.1)
    print("Class Name -",classname)
    wait(0.1)
    print("Data Cost",datacost)
    wait(0.1)
    print("Dev Camera Occlusion Mode -",devcameraocclusionmode)
    wait(0.1)
    print("Dev Computer Camera Mode -",devcomputercameramode)
    wait(0.1)
    print("Dev Computer Movement Mode -",devcomputermovementmode)
    wait(0.1)
    print("Dev Enable Mouse Lock =",devenablemouselock)
    wait(0.1)
    print("Dev Touch Camera Mode -",devtouchcameramode)
    wait(0.1)
    print("Dev Touch Movement Mode -",devtouchmovementmode)
    wait(0.1)
    print("Display Name -",displayname)
    wait(0.1)
    print("Follow User Id -",followuserid)
    wait(0.1)
    print("Guest =",guest)
    wait(0.1)
    print("Health Display Distance -",healthdisplaydistance)
    wait(0.1)
    print("Maximum Simulation Radius -",maximumsimulationradius)
    wait(0.1)
    print("Membership Type -",membershiptype)
    wait(0.1)
    print("Name -",name)
    wait(0.1)
    print("Name Display Distance -",namedisplaydistance)
    wait(0.1)
    print("Neutral =",neutral)
    wait(0.1)
    print("OsPlatform -",OsPlatform)
    wait(0.1)
    print("Parent -",parent)
    wait(0.1)
    print("Replication Focus -",replicationfocus)
    wait(0.1)
    print("Respawn Location -",respawnlocation)
    wait(0.1)
    print("Roblox Locked =",robloxlocked)
    wait(0.1)
    print("Team -",team)
    wait(0.1)
    print("Team Color -",teamcolor)
    wait(0.1)
    print("Teleported In =",teleportedin)
    wait(0.1)
    print("User Id  #",userid)
    wait(0.1)
    print("VRDevice -",vrdevice)
    wait(0.1)
    print("Has Verified Badge =",hasverifiedbadge)
    wait(0.1)
    print("Gameplay Paused =",gameplaypaused)