-- Made by Cole

local rootPart = game.Players.LocalPlayer.Character.HumanoidRootPart
print("Started Autofarm")
while wait(5) do
rootPart.CFrame = CFrame.new(0, 37301.25, -1513, 1, 0, 0, 0, 1, 0, 0, 0, 1)
end