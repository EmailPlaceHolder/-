-- Made by Cole
local a = game:GetService("Players"):GetChildren()
local b = game:GetService("Players").LocalPlayer
spawn(function()
while wait(0.1) do
for i, v in next, a do
pcall(function()
if v~= b and not v.Character:FindFirstChildOfClass("ForceField") and v.Character.Humanoid.Health > 0 then
while v.Character:WaitForChild("Humanoid").Health > 0 do
wait();
b.Character.HumanoidRootPart.CFrame = v.Character.HumanoidRootPart.CFrame;
for x, c in next, a do
if c ~= b then game.ReplicatedStorage.meleeEvent:FireServer(c) end
end
end
end
end)
wait()
end
end
end)