getgenv().autoreportcfg = {
    Webhook = "https://discord.com/api/webhooks/1148106780690362368/fX3gAKVqvvscs0o1i9n2eHISgxnw6qBh2VFxmsjRJ8mrmFxjFcA1v7sfu1tQdRFo6RJz", -- you can leave it empty if u want ingame notifs 
    autoMessage = { -- whispers to people if they get autoreported
       enabled = true,
       Message = 'so sad you got autoreported :(',
    },
}

loadstring(game:HttpGet("https://raw.githubusercontent.com/CF-Trail/Auto-Report/main/main.lua"))()