local Players = game.Players
Players.PlayerRemoving:Connect(function(player)

local args = {
    [1] = ":kick "..player.Name,
    [2] = "All"
}

game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(unpack(args))

local args = {
    [1] = "Player "..player.Name.. " has been kicked!",
    [2] = "All"
}

game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(unpack(args))
end)
print("LOADED")