-- Anti Fling
-- // Constants \\ --
-- [ Services ] --
local Services = setmetatable({}, {__index = function(Self, Index)
local NewService = game.GetService(game, Index)
if NewService then
Self[Index] = NewService
end
return NewService
end})

-- [ LocalPlayer ] --
local LocalPlayer = Services.Players.LocalPlayer

-- // Functions \\ --
local function PlayerAdded(Player)
   local Detected = false
   local Character;
   local PrimaryPart;

   local function CharacterAdded(NewCharacter)
       Character = NewCharacter
       repeat
           wait()
           PrimaryPart = NewCharacter:FindFirstChild("HumanoidRootPart")
       until PrimaryPart
       Detected = false
   end

   CharacterAdded(Player.Character or Player.CharacterAdded:Wait())
   Player.CharacterAdded:Connect(CharacterAdded)
   Services.RunService.Heartbeat:Connect(function()
       if (Character and Character:IsDescendantOf(workspace)) and (PrimaryPart and PrimaryPart:IsDescendantOf(Character)) then
           if PrimaryPart.AssemblyAngularVelocity.Magnitude > 50 or PrimaryPart.AssemblyLinearVelocity.Magnitude > 100 then
               if Detected == false then
                   game.StarterGui:SetCore("ChatMakeSystemMessage", {
                       Text = "Fling Exploit detected, Player: " .. tostring(Player);
                       Color = Color3.fromRGB(255, 200, 0);
                   })
               end
               Detected = true
               for i,v in ipairs(Character:GetDescendants()) do
                   if v:IsA("BasePart") then
                       v.CanCollide = false
                       v.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
                       v.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
                       v.CustomPhysicalProperties = PhysicalProperties.new(0, 0, 0)
                   end
               end
               PrimaryPart.CanCollide = false
               PrimaryPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
               PrimaryPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
               PrimaryPart.CustomPhysicalProperties = PhysicalProperties.new(0, 0, 0)
           end
       end
   end)
end

-- // Event Listeners \\ --
for i,v in ipairs(Services.Players:GetPlayers()) do
   if v ~= LocalPlayer then
       PlayerAdded(v)
   end
end
Services.Players.PlayerAdded:Connect(PlayerAdded)

local LastPosition = nil
Services.RunService.Heartbeat:Connect(function()
   pcall(function()
       local PrimaryPart = LocalPlayer.Character.PrimaryPart
       if PrimaryPart.AssemblyLinearVelocity.Magnitude > 250 or PrimaryPart.AssemblyAngularVelocity.Magnitude > 250 then
           PrimaryPart.AssemblyAngularVelocity = Vector3.new(0, 0, 0)
           PrimaryPart.AssemblyLinearVelocity = Vector3.new(0, 0, 0)
           PrimaryPart.CFrame = LastPosition

           game.StarterGui:SetCore("ChatMakeSystemMessage", {
               Text = "You were flung. Neutralizing velocity.";
               Color = Color3.fromRGB(255, 0, 0);
           })
       elseif PrimaryPart.AssemblyLinearVelocity.Magnitude < 50 or PrimaryPart.AssemblyAngularVelocity.Magnitude > 50 then
           LastPosition = PrimaryPart.CFrame
       end
   end)
end)

-- Fling All
local lp = game.Players.LocalPlayer
repeat
    wait()
until lp and lp.Character and lp.Character:FindFirstChild("HumanoidRootPart")
local rservice = game:GetService("RunService")
for _, z in next, game:GetDescendants() do
    if z:IsA "Seat" then
        z.Disabled = true
    end
end
function addFling()
    for _, child in pairs(lp.Character:GetDescendants()) do
        if child:IsA "BasePart" then
            child.CustomPhysicalProperties = PhysicalProperties.new(1, 1, 1, 1, 1)
        end
    end
    local BG = Instance.new("BodyGyro", lp.Character.HumanoidRootPart)
    local BV = Instance.new("BodyVelocity", lp.Character.HumanoidRootPart)
    BG.P = 9e4
    BG.maxTorque = Vector3.new(9e9, 9e9, 9e9)
    BG.cframe = lp.Character.HumanoidRootPart.CFrame
    BV.velocity = Vector3.new(1, 1, 1)
    BV.maxForce = Vector3.new(999e9, 999e9, 999e9)
    spawn(
        function()
            while wait() do
                pcall(
                    function()
                        BG.cframe = lp.Character.HumanoidRootPart.CFrame
                    end
                )
            end
        end
    )
    local BT = Instance.new("BodyThrust")
    BT.Parent = lp.Character.HumanoidRootPart
    BT.Force = Vector3.new(500000, 500000, 500000)
    BT.Location = lp.Character.HumanoidRootPart.Position
end
addFling()
lp.CharacterAdded:Connect(
    function(model)
        repeat
            wait()
        until model and model:FindFirstChildOfClass("Humanoid")
        if model:FindFirstChild("HumanoidRootPart") then
            addFling()
        end
    end
)
rservice.Stepped:Connect(
    function()
        if lp.Character and lp.Character:FindFirstChildOfClass("Humanoid") then
            if lp.Character:FindFirstChildOfClass("Humanoid").Sit == true then
                lp.Character:FindFirstChildOfClass("Humanoid"):ChangeState("Jumping")
            end
            for _, z in next, lp.Character:GetChildren() do
                if z:IsA "BasePart" then
                    z.CanCollide = false
                end
            end
        end
    end
)
coroutine.resume(
    coroutine.create(
        function()
            while wait(0) do
                pcall(
                    function()
                        for _, z in pairs(game.Players:GetPlayers()) do
                            if z ~= lp then
                                if
                                    lp.Character and lp.Character:FindFirstChild("HumanoidRootPart") and z and
                                        z.Character and
                                        z.Character:FindFirstChildOfClass("Humanoid").Sit == false and
                                        z.Character:FindFirstChildOfClass("Humanoid").FloorMaterial ~= Enum.Material.Air
                                 then
                                    spawn(
                                        function()
                                            pcall(
                                                function()
                                                    lp.Character:FindFirstChild("HumanoidRootPart").CFrame =
                                                        z.Character:FindFirstChild("HumanoidRootPart").CFrame
                                                    wait(0)
                                                    lp.Character:FindFirstChild("HumanoidRootPart").CFrame =
                                                        z.Character:FindFirstChild("HumanoidRootPart").CFrame
                                                end
                                            )
                                        end
                                    )
                                    wait(0)
                                end
                            end
                        end
                    end
                )
            end
        end
    )
)
