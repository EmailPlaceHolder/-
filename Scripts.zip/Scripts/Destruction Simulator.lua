while wait() do
game:GetService("ReplicatedStorage").Remotes.generateBoost:FireServer("Coins", 480, 9223372036854775807)
game:GetService("ReplicatedStorage").Remotes.generateBoost:FireServer("Levels", 480, 10)
end