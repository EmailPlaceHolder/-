loadstring(game:HttpGet("https://raw.githubusercontent.com/SkireScripts/Ouxie/main/Utils/Spotify%20Player/Source.lua"))():load({
    scale = 1; -- ui scale -- normal
    volume = 0.6; -- track vol -- normal
    track = "https://open.spotify.com/playlist/0d7uny6Peb8Eu2XFvKRT0S"; -- supports types track and playlist
    --                               ^^^^^^ - type
})