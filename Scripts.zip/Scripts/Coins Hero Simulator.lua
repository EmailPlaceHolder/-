loadstring(game:HttpGet(("https://raw.githubusercontent.com/5Picklebarry/Scripts/main/Pickle-Hub/Pickle-Hub-Loader.lua")))()

_G.on = true-- change true or false
while wait(0.1) do
    pcall(function()
if _G.on == true then
game:GetService("ReplicatedStorage").CoinToPlayer:FireServer(3)
game:GetService("ReplicatedStorage").Remotes.Skill:FireServer("Cosmos",{math.huge,0,0,0})
game:GetService("ReplicatedStorage").Remotes.Sell:FireServer()
game:GetService("ReplicatedStorage").Remotes.BuyAllSkills:InvokeServer("Cosmos")
game:GetService("ReplicatedStorage").Remotes.BuyAllBackpacks:InvokeServer()
game:GetService("ReplicatedStorage").Remotes.Rank:InvokeServer()

local args = {
    [1] = "Twister"
}

game:GetService("ReplicatedStorage").Remotes.Skill:FireServer(unpack(args))

local args = {
    [1] = "Tremor",
    [2] = {
        [1] = 0,
        [2] = 0,
        [3] = 0,
        [4] = 0,
        [5] = 0,
        [6] = 0
    }
}

game:GetService("ReplicatedStorage").Remotes.Skill:FireServer(unpack(args))

local args = {
    [1] = "Summoner"
}

game:GetService("ReplicatedStorage").Remotes.Skill:FireServer(unpack(args))

end
end)
end
