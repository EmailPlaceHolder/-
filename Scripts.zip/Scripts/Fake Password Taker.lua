local target = ""

game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("🔓: Cracking "..target.."'s Password..." ,"All")

wait(3)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("📟: Decrypting "..target.."'s Password" ,"All")

wait(2)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("✅20% ✅40% ✅60% completed." ,"All")

wait(1)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("📤: "..target.."'s password has been unhashed," ,"All")

wait(2)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("🔏: Successfully taken "..target.."'s password..." ,"All")

wait(1)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("🔑: Successfully logged "..target.."'s password!" ,"All")

wait(2)
game.ReplicatedStorage.DefaultChatSystemChatEvents.SayMessageRequest:FireServer("Thank you, "..target..". 🙂" ,"All")

warn("🔓: Cracked "..target.."'s Password")