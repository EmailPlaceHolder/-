-- INJECT SEPERATLY!!! #1, #2 & #3

-- Remove All Bad Glass [#1] >
while true and task.wait() do
for i,v in pairs(game:GetService("Workspace")["Glass Bridge"].GlassPane:GetDescendants()) do
   if v.Name == 'TouchInterest' then
       v.Parent.Transparency = 1

-- Infinite Cash [#2] >
while wait() do
game:GetService("ReplicatedStorage").SpinEvent.Request:InvokeServer()

-- Result from Response [#3] >
wait(5) do
print("Spinning wheel on repeat...")
end
end
end
end
end