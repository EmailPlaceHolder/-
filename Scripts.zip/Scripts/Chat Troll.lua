--BROUGHT TO YOU BY RSCRIPTS.NET!--


local IGNOREIFINANTIEXPLOIT = Instance.new("ScreenGui")
local Border = Instance.new("ImageLabel")
local Frame = Instance.new("ImageLabel")
local TextLabel = Instance.new("TextLabel")
local YourChat = Instance.new("TextBox")
local TextLabel_2 = Instance.new("TextLabel")
local TextLabel_3 = Instance.new("TextLabel")
local TextLabel_4 = Instance.new("TextLabel")
local Username = Instance.new("TextBox")
local FakeChat = Instance.new("TextBox")
local TextLabel_5 = Instance.new("TextLabel")
local Chat = Instance.new("TextButton")

IGNOREIFINANTIEXPLOIT.Name = "IGNORE IF IN ANTI EXPLOIT"
IGNOREIFINANTIEXPLOIT.Parent = game.CoreGui

Border.Name = "Border"
Border.Parent = IGNOREIFINANTIEXPLOIT
Border.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Border.BackgroundTransparency = 1.000
Border.BorderSizePixel = 0
Border.Position = UDim2.new(0.385948896, 0, 0.250995994, 0)
Border.Size = UDim2.new(0, 250, 0, 250)
Border.Image = "rbxassetid://3570695787"
Border.ImageColor3 = Color3.fromRGB(0, 0, 0)
Border.ScaleType = Enum.ScaleType.Slice
Border.SliceCenter = Rect.new(100, 100, 100, 100)
Border.SliceScale = 0.120
Border.Selectable = true
Border.Draggable = true
Border.Active = true

Frame.Name = "Frame"
Frame.Parent = Border
Frame.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
Frame.BackgroundTransparency = 1.000
Frame.BorderSizePixel = 0
Frame.Position = UDim2.new(0.0234233439, 0, 0.0229482204, 0)
Frame.Size = UDim2.new(0, 238, 0, 238)
Frame.Image = "rbxassetid://3570695787"
Frame.ImageColor3 = Color3.fromRGB(40, 40, 40)
Frame.ScaleType = Enum.ScaleType.Slice
Frame.SliceCenter = Rect.new(100, 100, 100, 100)
Frame.SliceScale = 0.120

TextLabel.Parent = Frame
TextLabel.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel.BackgroundTransparency = 1.000
TextLabel.Size = UDim2.new(0, 238, 0, 30)
TextLabel.Font = Enum.Font.Creepster
TextLabel.Text = "Chat Troll GUI"
TextLabel.TextColor3 = Color3.fromRGB(255, 0, 127)
TextLabel.TextScaled = true
TextLabel.TextSize = 14.000
TextLabel.TextWrapped = true

YourChat.Name = "YourChat"
YourChat.Parent = Frame
YourChat.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
YourChat.BorderSizePixel = 0
YourChat.Position = UDim2.new(0.0798319355, 0, 0.264705896, 0)
YourChat.Size = UDim2.new(0, 200, 0, 25)
YourChat.Font = Enum.Font.SourceSans
YourChat.Text = ""
YourChat.TextColor3 = Color3.fromRGB(255, 0, 127)
YourChat.TextScaled = true
YourChat.TextSize = 14.000
YourChat.TextWrapped = true

TextLabel_2.Parent = Frame
TextLabel_2.BackgroundColor3 = Color3.fromRGB(0, 0, 0)
TextLabel_2.BorderSizePixel = 0
TextLabel_2.Position = UDim2.new(0, 0, 0.126050428, 0)
TextLabel_2.Size = UDim2.new(0, 238, 0, 5)
TextLabel_2.Font = Enum.Font.Creepster
TextLabel_2.Text = ""
TextLabel_2.TextColor3 = Color3.fromRGB(255, 0, 127)
TextLabel_2.TextScaled = true
TextLabel_2.TextSize = 14.000
TextLabel_2.TextWrapped = true

TextLabel_3.Parent = Frame
TextLabel_3.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_3.BackgroundTransparency = 1.000
TextLabel_3.Position = UDim2.new(0, 0, 0.163865551, 0)
TextLabel_3.Size = UDim2.new(0, 238, 0, 18)
TextLabel_3.Font = Enum.Font.Arial
TextLabel_3.Text = "Your Chat"
TextLabel_3.TextColor3 = Color3.fromRGB(255, 0, 127)
TextLabel_3.TextScaled = true
TextLabel_3.TextSize = 14.000
TextLabel_3.TextWrapped = true

TextLabel_4.Parent = Frame
TextLabel_4.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_4.BackgroundTransparency = 1.000
TextLabel_4.Position = UDim2.new(0, 0, 0.394957989, 0)
TextLabel_4.Size = UDim2.new(0, 238, 0, 18)
TextLabel_4.Font = Enum.Font.Arial
TextLabel_4.Text = "Username"
TextLabel_4.TextColor3 = Color3.fromRGB(255, 0, 127)
TextLabel_4.TextScaled = true
TextLabel_4.TextSize = 14.000
TextLabel_4.TextWrapped = true

Username.Name = "Username"
Username.Parent = Frame
Username.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Username.BorderSizePixel = 0
Username.Position = UDim2.new(0.0798319355, 0, 0.495798349, 0)
Username.Size = UDim2.new(0, 200, 0, 25)
Username.Font = Enum.Font.SourceSans
Username.Text = ""
Username.TextColor3 = Color3.fromRGB(255, 0, 127)
Username.TextScaled = true
Username.TextSize = 14.000
Username.TextWrapped = true

FakeChat.Name = "FakeChat"
FakeChat.Parent = Frame
FakeChat.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
FakeChat.BorderSizePixel = 0
FakeChat.Position = UDim2.new(0.0798319355, 0, 0.726890802, 0)
FakeChat.Size = UDim2.new(0, 200, 0, 25)
FakeChat.Font = Enum.Font.SourceSans
FakeChat.Text = ""
FakeChat.TextColor3 = Color3.fromRGB(255, 0, 127)
FakeChat.TextScaled = true
FakeChat.TextSize = 14.000
FakeChat.TextWrapped = true

TextLabel_5.Parent = Frame
TextLabel_5.BackgroundColor3 = Color3.fromRGB(255, 255, 255)
TextLabel_5.BackgroundTransparency = 1.000
TextLabel_5.Position = UDim2.new(0, 0, 0.626050413, 0)
TextLabel_5.Size = UDim2.new(0, 238, 0, 18)
TextLabel_5.Font = Enum.Font.Arial
TextLabel_5.Text = "Fake Chat"
TextLabel_5.TextColor3 = Color3.fromRGB(255, 0, 127)
TextLabel_5.TextScaled = true
TextLabel_5.TextSize = 14.000
TextLabel_5.TextWrapped = true

Chat.Name = "Chat"
Chat.Parent = Frame
Chat.BackgroundColor3 = Color3.fromRGB(30, 30, 30)
Chat.BorderColor3 = Color3.fromRGB(30, 30, 30)
Chat.BorderSizePixel = 0
Chat.Position = UDim2.new(0.184873953, 0, 0.865546227, 0)
Chat.Size = UDim2.new(0, 150, 0, 25)
Chat.Font = Enum.Font.Code
Chat.Text = "Chat"
Chat.TextColor3 = Color3.fromRGB(255, 0, 127)
Chat.TextScaled = true
Chat.TextSize = 14.000
Chat.TextWrapped = true
Chat.MouseButton1Down:connect(function()
local A_1 = YourChat.Text.."                                                                                                                                            ".."["..Username.Text.."]: ".. FakeChat.Text
local A_2 = "All"
local Event = game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest
Event:FireServer(A_1, A_2)
end)

-- Scripts:

local function GATORUS_fake_script() -- TextLabel_2.LocalScript
local script = Instance.new('LocalScript', TextLabel_2)

function zigzag(X) return math.acos(math.cos(X*math.pi))/math.pi end

counter = 0

while wait(0.1)do
script.Parent.BackgroundColor3 = Color3.fromHSV(zigzag(counter),1,1)

counter = counter + 0.01
end
end
coroutine.wrap(GATORUS_fake_script)()
local function EQITSSO_fake_script() -- Border.LocalScript
local script = Instance.new('LocalScript', Border)

function zigzag(X) return math.acos(math.cos(X*math.pi))/math.pi end

counter = 0

while wait(0.1)do
script.Parent.ImageColor3 = Color3.fromHSV(zigzag(counter),1,1)

counter = counter + 0.01
end
end
coroutine.wrap(EQITSSO_fake_script)()