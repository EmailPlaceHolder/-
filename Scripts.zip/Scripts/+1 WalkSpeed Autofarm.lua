-- Made by Cole
-- Anti AFK
    wait(1)
    local ba=Instance.new("ScreenGui")
    local ca=Instance.new("TextLabel")
    local da=Instance.new("Frame")
    local _b=Instance.new("TextLabel")
    local ab=Instance.new("TextLabel")
    ba.Parent=game.CoreGui
    ba.ZIndexBehavior=Enum.ZIndexBehavior.Sibling;ca.Parent=ba;ca.Active=true
    ca.BackgroundColor3=Color3.new(0.176471,0.176471,0.176471)ca.Draggable=true
    ca.Position=UDim2.new(0.698610067,0,0.098096624,0)ca.Size=UDim2.new(0,370,0,52)
    ca.Font=Enum.Font.SourceSansSemibold;ca.Text="Anti AFK"ca.TextColor3=Color3.new(0,1,1)
    ca.TextSize=20;da.Parent=ca
    da.BackgroundColor3=Color3.new(0.196078,0.196078,0.196078)da.Position=UDim2.new(0,0,1.0192306,0)
    da.Size=UDim2.new(0,370,0,107)_b.Parent=da
    _b.BackgroundColor3=Color3.new(0.176471,0.176471,0.176471)_b.Position=UDim2.new(0,0,0.800455689,0)
    _b.Size=UDim2.new(0,370,0,21)_b.Font=Enum.Font.Arial;_b.Text="Cole.exe"
    _b.TextColor3=Color3.new(0,1,1)_b.TextSize=20;ab.Parent=daaaaaaaaaa
    ab.BackgroundColor3=Color3.new(0.176471,0.176471,0.176471)ab.Position=UDim2.new(0,0,0.158377,0)
    ab.Size=UDim2.new(0,370,0,44)ab.Font=Enum.Font.ArialBold;ab.Text="Status: Active"
    ab.TextColor3=Color3.new(0,1,1)ab.TextSize=20;local bb=game:service'VirtualUser'
    game:service'Players'.LocalPlayer.Idled:connect(function()
    bb:CaptureController()bb:ClickButton2(Vector2.new())
    ab.Text="Roblox Tried Kicking You"wait(1)ab.Text="Status: Active"end)
-- Identifiers
local Player = game:GetService("Players").LocalPlayer
local Character = Player.Character
-- Stats *
    local stat1A = game.Players.LocalPlayer.DisplayName
    local stat1B = game.Players.LocalPlayer.UserId
    local stat1C = game.Players.LocalPlayer.AccountAge
    local stat1D = game.Players.LocalPlayer.MembershipType.Name
    local stat1E = game.Players.LocalPlayer.CameraMode.Name
    local stat1F = game.Players.LocalPlayer.CurrentZone.Value
    local stat1G = game.Players.LocalPlayer.EquippedTrail.Value
-- Overview
    local stat2A = game.Players.LocalPlayer.leaderstats.Rebirth.Value
    local stat2B = game.Players.LocalPlayer.PlayTime.Value
    local stat2C = game.Players.LocalPlayer.multiplier.Value
    local stat2D = game.Players.LocalPlayer.friendboost.Value
    local stat2E = game.Players.LocalPlayer.Streak.Value
-- Speed
    local stat3A = game.Players.LocalPlayer.leaderstats.WalkSpeed.Value
    local stat3B = game.Players.LocalPlayer.usingChosenSpeed.Value
    local stat3C = game.Players.LocalPlayer.chosenSpeed.Value
    local stat3D = game.Players.LocalPlayer.boostspeed.Value
-- Wins
    local stat4A = game.Players.LocalPlayer.leaderstats.Wins.Value
    local stat4B = game.Players.LocalPlayer.requiredwins.Value
    local stat4C = game.Players.LocalPlayer.x2wins.Value
    local stat4D = game.Players.LocalPlayer.boostwins.Value
-- Rewards
    local stat5A = game.Players.LocalPlayer.Daily.Value
    local stat5B = game.Players.LocalPlayer.GroupReward.Value
    local stat5C = game.Players.LocalPlayer.PremiumReward.Value
-- Best stage
local winA = workspace.Wins.CandyStage -- 1st
-- local winB = workspace.Wins.Stage -- 2nd
-- Response
    warn("LOADING")
    warn("Made by Cole")
    wait(1)
    game.TestService:Message("Stats")
    wait(0.1)
    print("User -",Player)
    wait(0.1)
    print("Display Name -",stat1A)
    wait(0.1)
    print("User ID -",stat1B)
    wait(0.1)
    print("Account Age -",stat1C)
    wait(0.1)
    print("Membership Type -",stat1D)
    wait(0.1)
    print("Camera Mode -",stat1E)
    wait(0.1)
    print("Current Zone -",stat1F)
    wait(0.1)
    print("Equipped Trail -",stat1G)
    wait(0.1)
    game.TestService:Message("Overview")
    wait(0.1)
    print("Current Rebirths -",stat2A)
    wait(0.1)
    print("Play Time -",stat2B)
    wait(0.1)
    print("Multiplier -",stat2C)
    wait(0.1)
    print("Friend Boost -",stat2D)
    wait(0.1)
    print("Streak -",stat2E)
    wait(0.1)
    game.TestService:Message("Speed")
    wait(0.1)
    print("Current Speed -",stat3A)
    wait(0.1)
    print("Using Chosen Speed =",stat3B)
    wait(0.1)
    print("Chosen Speed -",stat3C)
    wait(0.1)
    print("Boost Speed -",stat3D)
    wait(0.1)
    game.TestService:Message("Wins")
    wait(0.1)
    print("Current Wins -",stat4A)
    wait(0.1)
    print("Required Wins -",stat4B)
    wait(0.1)
    print("x2wins =",stat4C)
    wait(0.1)
    print("Boost Wins -",stat4D)
    wait(0.1)
    game.TestService:Message("Rewards")
    wait(0.1)
    print("Daily Reward -",stat5A)
    wait(0.1)
    print("Group Reward -",stat5B)
    wait(0.1)
    print("Premium Reward -",stat5C)
    wait(0.1)
    warn("SUCCESS")
-- Results
game.TestService:Message("Results")
print("Initiating Rebirths:")
print("Starting Autofarm...")
-- Loop
while wait(0) do
wait(0)
firetouchinterest(Character.HumanoidRootPart, winA, 0)
firetouchinterest(Character.HumanoidRootPart, winA, 1)
wait(0)
firetouchinterest(Character.HumanoidRootPart, winA, 0)
firetouchinterest(Character.HumanoidRootPart, winA, 1)
wait(0)
firetouchinterest(Character.HumanoidRootPart, winA, 0)
firetouchinterest(Character.HumanoidRootPart, winA, 1)
wait(0)
firetouchinterest(Character.HumanoidRootPart, winA, 0)
firetouchinterest(Character.HumanoidRootPart, winA, 1)
-- Auto Rebirth
game:GetService("ReplicatedStorage").RebirthEvent:FireServer()
end