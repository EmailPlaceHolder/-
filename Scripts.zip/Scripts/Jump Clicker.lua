local Controller = require(game.Players.LocalPlayer.PlayerScripts.Client.Controllers.JumpingController)
while task.wait() do
pcall(function()
game.Players.LocalPlayer.Character.Humanoid:SetAttribute('JumpPower', 9223372036854775807)
Controller:Rise()
end)
end