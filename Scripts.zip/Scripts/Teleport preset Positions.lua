local time_wait = 0.1 -- wait time
local plr = game:GetService("Players").LocalPlayer
local todo = game:GetService("Workspace").insert:GetChildren()
for i,v in pairs(todo) do
    local Pos = todo[i].Position
    plr.character.HumanoidRootPart.CFrame = CFrame.new(Pos)
    wait(time_wait)
end