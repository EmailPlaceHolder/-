-- Upgraded by Cole
-- Works 04/02/2024

loadstring(game:HttpGet('https://github.com/KhSaeed90/Roblox/raw/workspace/6766156863'))()
loadstring(game:HttpGet('https://raw.githubusercontent.com/ToraScript/Script/main/SwordStrongman'))()
while wait() do
local args = {
    [1] = "BoosterShop"
}
game:GetService("ReplicatedStorage").KnivstaShop_RollShop:InvokeServer(unpack(args))
end