-- Made by Cole
for i,v in ipairs(workspace["insert"]:GetChildren()) do
firetouchinterest(v, game.Players.LocalPlayer.Character.PrimaryPart, 0)
end